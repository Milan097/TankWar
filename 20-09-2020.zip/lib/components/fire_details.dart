

import 'package:flutter/material.dart';

class FireDetails {
  double power;
  double angle;
  Offset firePosition;

  FireDetails({this.power, this.angle, this.firePosition});
}