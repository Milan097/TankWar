enum Status {
  lobby,
  starting,
  playing,
  roundOver,
  gameOver,
  weapon,
  support,
}