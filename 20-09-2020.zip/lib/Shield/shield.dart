import 'package:flutter/cupertino.dart';

class ShieldDetails {
  double maxHealth;
  double curHealth;
//  Offset shieldPosition;
  Color color;
}