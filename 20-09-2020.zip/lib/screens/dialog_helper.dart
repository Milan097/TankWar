import 'package:flutter/material.dart';
import 'package:tankwar/screens/weapon_dialog.dart';

class DialogHelper {

//  static open(context,weapon) => showDialog(context: context, builder: (context) => WeaponDialog(weapon: weapon,));
}