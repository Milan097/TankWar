enum ControllerStatus {
  main,
  move,
  weapon,
  angle,
  power,
  buff,
  confirming,
}