package com.code4ij.tankwar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
